import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function XSpawnApp() {
  const [connected, setConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        setWalletAddress(accounts[0]);
        setConnected(true);
      } catch (error) {
        console.error('Connection error:', error);
      }
    } else {
      alert('Metamask not detected. Please install it to continue.');
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white font-sans">
      <header className="text-center py-12">
        <h1 className="text-5xl font-extrabold tracking-tight">XSpawn (XPS)</h1>
        <p className="mt-6 text-xl max-w-3xl mx-auto">
          XSpawn is a gaming token built on the Layer One X (L1X) blockchain, designed to power the Web3 gaming economy.
        </p>
        <p className="mt-4 max-w-2xl mx-auto text-gray-400">
          Through X-Talk technology, XSpawn enables fast and secure cross-chain interactions without the use of bridges,
          paving the way for a connected, competitive, and decentralized metaverse.
        </p>
        <p className="mt-6 italic text-lg font-medium">
          “Spawn your power. Earn your glory. Rule the chain.”
        </p>
      </header>

      <section className="flex justify-center">
        {!connected ? (
          <Button onClick={connectWallet} className="bg-green-600 hover:bg-green-700 px-8 py-4 text-lg rounded-full">
            Connect Wallet
          </Button>
        ) : (
          <div className="bg-gray-800 p-6 rounded-xl shadow-lg">
            <p className="text-gray-400 text-sm">Connected wallet:</p>
            <p className="text-green-400 font-mono text-sm break-all mt-1">{walletAddress}</p>
          </div>
        )}
      </section>

      <footer className="text-center mt-24 text-sm text-gray-500">
        &copy; {new Date().getFullYear()} XSpawn. All rights reserved.
      </footer>
    </main>
  );
}

/* === INSTRUCȚIUNI PENTRU PUBLICARE PE GITHUB ===
1. Creează un repository nou pe GitHub (ex. xspawn-site)
2. Pe computerul tău:
   - Deschide terminalul în directorul proiectului
   - Rulează:
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/USERNAME/xspawn-site.git
     git push -u origin main

3. În GitHub > Settings > Pages:
   - Selectează branch: `main`, folder: `/ (root)` și salvează
   - În câteva minute site-ul tău va fi disponibil la: https://USERNAME.github.io/xspawn-site

Pentru proiecte cu React + Vite:
- Asigură-te că ai `vite.config.js` cu:
    base: '/xspawn-site/'
- Și că ai un script `"deploy"` în `package.json` pentru GitHub Pages
*/
